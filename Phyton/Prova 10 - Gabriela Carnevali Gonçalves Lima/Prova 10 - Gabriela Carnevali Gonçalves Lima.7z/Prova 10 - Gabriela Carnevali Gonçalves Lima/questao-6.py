# coding: UTF-8 -*-

print("Olá usuário! Digite um número inteiro e eu te direi os valores pares da sequência de Fibonacci até chegar nele")

num = int(input("Digite um número inteiro: "))

for i in range (0, num, 2):
    print(i)
