# -*- coding: UTF-8 -*-

print ("Exibirei a tabuada do 0 ao 9")

#i: variável de contagem depois do for. I é a contagem automática do while +=1
for i in range (0,10):

    for j in range (0,11):
        print(f"{j} x {i} = {i*j}")

    
