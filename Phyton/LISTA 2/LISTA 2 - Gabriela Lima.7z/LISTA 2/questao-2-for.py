# -*- coding: UTF-8 -*-

print(" Calcularei a soma dos primeiros 50 números pares")
soma = 0

for v in range (0,101,2):
    soma += v

print(soma)
    

 
