# -*- coding: UTF-8 -*-

print("Mostrarei os números na tela de 1 a 50 em ordem crescente e decrescente")

for v in range (1,51):
    print(v)
    
for j in range (50,0,-1):
    print (j)
