# -*- coding: UTF-8 -*-

print ("Olá usuário! Digite um valor inteiro (sem vírgula) e eu te direi se ele é par ou ímpar")

valor = int(input("Digite o valor desejado: "))

if valor %2 == 0:
    print("O número é par")
else:
    print ("O número é ímpar")
