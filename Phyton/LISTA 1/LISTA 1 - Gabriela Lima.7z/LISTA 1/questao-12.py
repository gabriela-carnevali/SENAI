# -*- coding: UTF-8 -*-

print("Digite duas variáveis inteiras e eu as colocarei em ordem crescente")
num1 = int(input("Digite o primeiro valor: "))
num2 = int(input("Digite o segundo valor: "))

if num1 > num2:
     a = num2
     b = num1
     print("O valor a é: ", a)
     print("O valor b é: ", b)
else:
    a = num1
    b = num2
    num2 > num1
    print("O primeiro valor é: ", a)
    print("O segundo valor é: ", b)
    
