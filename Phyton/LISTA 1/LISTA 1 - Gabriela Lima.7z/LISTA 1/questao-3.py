# -*- coding: UTF-8 -*-

print("Olá usuário! Me dê dois números inteiros (sem vígula) e eu te direi o maior")
valor1 = int(input("Digite o primeiro valor: "))
valor2 = int(input("Digite o segundo valor: "))

if valor1 > valor2:
    print("O resultado é igual a: ", valor1)
else:
    print("O resultado é igual a: ", valor2)
